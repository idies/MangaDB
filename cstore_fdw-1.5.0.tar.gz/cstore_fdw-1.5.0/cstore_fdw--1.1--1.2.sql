/* cstore_fdw/cstore_fdw--1.1--1.2.sql */

-- No new functions or definitions were added in 1.2
